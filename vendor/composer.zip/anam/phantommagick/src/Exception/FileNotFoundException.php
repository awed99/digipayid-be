<?php

namespace Anam\Html2PdfConverter\Exception;

use Exception;

class FileNotFoundException extends Exception
{

}
